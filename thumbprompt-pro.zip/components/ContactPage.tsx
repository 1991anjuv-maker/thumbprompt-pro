import React, { useState } from 'react';

export const ContactPage: React.FC = () => {
  const [status, setStatus] = useState<'idle' | 'success'>('idle');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Simulate form submission
    setStatus('success');
  };

  return (
    <div className="max-w-4xl mx-auto px-6 py-16 text-gray-300 animate-fadeIn">
      <div className="grid md:grid-cols-2 gap-12">
        <div className="space-y-6">
          <h1 className="text-4xl font-bold text-white">Contact Us</h1>
          <p className="text-lg leading-relaxed text-gray-400">
            Have questions about prompt engineering? Found a bug? Or just want to say hi? We'd love to hear from you.
          </p>
          
          <div className="space-y-4 mt-8">
            <div className="flex items-start gap-4">
              <div className="p-3 bg-dark-800 rounded-lg border border-gray-700">
                <svg className="w-6 h-6 text-brand-500" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" /></svg>
              </div>
              <div>
                <h3 className="font-bold text-white">Email Us</h3>
                <p className="text-sm text-gray-500">support@thumbprompt.pro</p>
                <p className="text-xs text-gray-600 mt-1">Response time: 24-48 hours.</p>
              </div>
            </div>
          </div>
        </div>

        <div className="bg-dark-800 p-8 rounded-2xl border border-gray-800 shadow-xl">
          {status === 'success' ? (
            <div className="text-center py-12 space-y-4">
              <div className="w-16 h-16 bg-green-500/10 text-green-500 rounded-full flex items-center justify-center mx-auto">
                <svg className="w-8 h-8" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" /></svg>
              </div>
              <h3 className="text-xl font-bold text-white">Message Sent!</h3>
              <p className="text-gray-400">Thank you for contacting us. We will get back to you shortly.</p>
              <button 
                onClick={() => setStatus('idle')}
                className="text-brand-500 hover:text-brand-400 text-sm font-medium mt-4"
              >
                Send another message
              </button>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-gray-500 uppercase mb-1">Name</label>
                <input required type="text" className="w-full bg-dark-900 border border-gray-700 rounded-lg p-3 text-white focus:ring-1 focus:ring-brand-500 outline-none" placeholder="Your name" />
              </div>
              <div>
                <label className="block text-xs font-bold text-gray-500 uppercase mb-1">Email</label>
                <input required type="email" className="w-full bg-dark-900 border border-gray-700 rounded-lg p-3 text-white focus:ring-1 focus:ring-brand-500 outline-none" placeholder="you@example.com" />
              </div>
              <div>
                <label className="block text-xs font-bold text-gray-500 uppercase mb-1">Message</label>
                <textarea required rows={4} className="w-full bg-dark-900 border border-gray-700 rounded-lg p-3 text-white focus:ring-1 focus:ring-brand-500 outline-none" placeholder="How can we help?"></textarea>
              </div>
              <button type="submit" className="w-full py-3 bg-brand-600 hover:bg-brand-500 text-white font-bold rounded-lg transition-colors">
                Send Message
              </button>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};