import React from 'react';

export const AboutUs: React.FC = () => (
  <div className="max-w-4xl mx-auto px-6 py-16 text-gray-300 animate-fadeIn">
    <h1 className="text-4xl font-bold text-white mb-8">About <span className="text-brand-500">ThumbPrompt Pro</span></h1>
    <div className="prose prose-invert max-w-none space-y-6">
      <p className="text-lg leading-relaxed">
        Welcome to ThumbPrompt Pro, a specialized AI-powered utility designed specifically for YouTube content creators. In an era where visual optimization is key, we provide the tools creators need to design compelling thumbnails efficiently.
      </p>
      
      <h3 className="text-2xl font-bold text-white mt-8">Our Mission</h3>
      <p>
        Our mission is to democratize high-end graphic design concepts using Artificial Intelligence. We believe that every creator, regardless of their artistic skill level or budget, deserves professional-quality thumbnails. ThumbPrompt Pro bridges the gap between your video idea and the perfect prompt for tools like Midjourney, DALL-E 3, and Stable Diffusion.
      </p>

      <h3 className="text-2xl font-bold text-white mt-8">Why Use ThumbPrompt?</h3>
      <ul className="list-disc pl-6 space-y-2">
        <li><strong>Privacy Focused:</strong> We operate with a privacy-first mindset. Your prompt history and creative ideas remain yours.</li>
        <li><strong>Platform Optimized:</strong> Unlike generic prompt generators, our algorithms are specifically tuned for YouTube's visual requirements—high contrast, emotional faces, and legible compositions.</li>
        <li><strong>Community Driven:</strong> We constantly update our keyword databases based on what is currently working on the YouTube homepage.</li>
      </ul>
    </div>
  </div>
);

export const PrivacyPolicy: React.FC = () => (
  <div className="max-w-4xl mx-auto px-6 py-16 text-gray-300 animate-fadeIn">
    <h1 className="text-4xl font-bold text-white mb-8">Privacy Policy</h1>
    <div className="prose prose-invert max-w-none space-y-6 text-sm md:text-base">
      <p>Last Updated: {new Date().toLocaleDateString()}</p>
      <p>
        At ThumbPrompt Pro, accessible from thumbprompt.pro, one of our main priorities is the privacy of our visitors. This Privacy Policy document contains types of information that is collected and recorded by ThumbPrompt Pro and how we use it.
      </p>

      <h3 className="text-xl font-bold text-white mt-6">Log Files</h3>
      <p>
        ThumbPrompt Pro follows a standard procedure of using log files. These files log visitors when they visit websites. All hosting companies do this as a part of hosting services' analytics. The information collected includes internet protocol (IP) addresses, browser type, Internet Service Provider (ISP), date and time stamp, referring/exit pages, and possibly the number of clicks. These are not linked to any information that is personally identifiable.
      </p>

      <h3 className="text-xl font-bold text-white mt-6">Cookies and Web Beacons</h3>
      <p>
        Like any other website, ThumbPrompt Pro uses 'cookies'. These cookies are used to store information including visitors' preferences, and the pages on the website that the visitor accessed or visited. The information is used to optimize the users' experience by customizing our web page content based on visitors' browser type and/or other information.
      </p>

      <h3 className="text-xl font-bold text-white mt-6">Google DoubleClick DART Cookie</h3>
      <p>
        Google is one of a third-party vendor on our site. It also uses cookies, known as DART cookies, to serve ads to our site visitors based upon their visit to our site and other sites on the internet. However, visitors may choose to decline the use of DART cookies by visiting the Google ad and content network Privacy Policy at the following URL – <a href="https://policies.google.com/technologies/ads" className="text-brand-500 hover:underline" target="_blank" rel="noreferrer">https://policies.google.com/technologies/ads</a>
      </p>

      <h3 className="text-xl font-bold text-white mt-6">Consent</h3>
      <p>
        By using our website, you hereby consent to our Privacy Policy and agree to its Terms and Conditions.
      </p>
    </div>
  </div>
);

export const TermsOfService: React.FC = () => (
  <div className="max-w-4xl mx-auto px-6 py-16 text-gray-300 animate-fadeIn">
    <h1 className="text-4xl font-bold text-white mb-8">Terms of Service</h1>
    <div className="prose prose-invert max-w-none space-y-6 text-sm md:text-base">
      <h3 className="text-xl font-bold text-white mt-6">1. Terms</h3>
      <p>
        By accessing this Website, accessible from thumbprompt.pro, you are agreeing to be bound by these Website Terms and Conditions of Use and agree that you are responsible for the agreement with any applicable local laws. If you disagree with any of these terms, you are prohibited from accessing this site.
      </p>

      <h3 className="text-xl font-bold text-white mt-6">2. Use License</h3>
      <p>
        Permission is granted to temporarily download one copy of the materials (information or software) on ThumbPrompt Pro's Website for personal, non-commercial transitory viewing only. This is the grant of a license, not a transfer of title, and under this license you may not:
      </p>
      <ul className="list-disc pl-6">
        <li>modify or copy the materials;</li>
        <li>use the materials for any commercial purpose or for any public display;</li>
        <li>attempt to reverse engineer any software contained on ThumbPrompt Pro's Website;</li>
        <li>remove any copyright or other proprietary notations from the materials; or</li>
        <li>transfer the materials to another person or "mirror" the materials on any other server.</li>
      </ul>

      <h3 className="text-xl font-bold text-white mt-6">3. Disclaimer</h3>
      <p>
        All the materials on ThumbPrompt Pro's Website are provided "as is". ThumbPrompt Pro makes no warranties, may it be expressed or implied, therefore negates all other warranties. Furthermore, ThumbPrompt Pro does not make any representations concerning the accuracy or likely results of the use of the materials on its Website or otherwise relating to such materials or on any sites linked to this site.
      </p>

      <h3 className="text-xl font-bold text-white mt-6">4. Limitations</h3>
      <p>
        In no event shall ThumbPrompt Pro or its suppliers be liable for any damages (including, without limitation, damages for loss of data or profit, or due to business interruption) arising out of the use or inability to use the materials on ThumbPrompt Pro's Website.
      </p>
      
      <h3 className="text-xl font-bold text-white mt-6">5. Educational Purpose</h3>
      <p>
        This tool is intended for educational and creative assistance purposes only. We do not guarantee any specific results on YouTube or other platforms regarding views, clicks, or revenue.
      </p>
    </div>
  </div>
);

export const Disclaimer: React.FC = () => (
  <div className="max-w-4xl mx-auto px-6 py-16 text-gray-300 animate-fadeIn">
    <h1 className="text-4xl font-bold text-white mb-8">Disclaimer</h1>
    <div className="prose prose-invert max-w-none space-y-6 text-sm md:text-base">
      <p>Last Updated: {new Date().toLocaleDateString()}</p>
      <h3 className="text-xl font-bold text-white mt-6">General Disclaimer</h3>
      <p>
        The information provided by ThumbPrompt Pro ("we," "us," or "our") on thumbprompt.pro (the "Site") is for general informational purposes only. All information on the Site is provided in good faith, however we make no representation or warranty of any kind, express or implied, regarding the accuracy, adequacy, validity, reliability, availability, or completeness of any information on the Site.
      </p>
      
      <h3 className="text-xl font-bold text-white mt-6">Not Affiliated with YouTube/Google</h3>
      <p>
        This tool is not affiliated with YouTube, Google, OpenAI, Midjourney, DALL·E, Stable Diffusion, or Adobe. All brand names are used only for reference and compatibility purposes.
      </p>

      <h3 className="text-xl font-bold text-white mt-6">External Links Disclaimer</h3>
      <p>
        The Site may contain (or you may be sent through the Site) links to other websites or content belonging to or originating from third parties or links to websites and features in banners or other advertising. Such external links are not investigated, monitored, or checked for accuracy, adequacy, validity, reliability, availability, or completeness by us.
      </p>

      <h3 className="text-xl font-bold text-white mt-6">Professional Disclaimer</h3>
      <p>
        The Site cannot and does not contain professional advice. The information is provided for general informational and educational purposes only and is not a substitute for professional advice. Accordingly, before taking any actions based upon such information, we encourage you to consult with the appropriate professionals.
      </p>
    </div>
  </div>
);