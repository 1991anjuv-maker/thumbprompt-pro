import React from 'react';
import { ThumbnailData, Niche, ColorTheme, BackgroundType, Lighting, FaceType, Composition } from '../types';

interface Props {
  data: ThumbnailData;
}

const getColorHex = (theme: ColorTheme): string => {
  switch (theme) {
    case ColorTheme.Red: return "#ef4444";
    case ColorTheme.Blue: return "#3b82f6";
    case ColorTheme.Green: return "#22c55e";
    case ColorTheme.Gold: return "#eab308";
    case ColorTheme.Neon: return "#d946ef";
    case ColorTheme.Dark: return "#1f2937";
    case ColorTheme.Pastel: return "#f9a8d4";
    default: return "#f43f5e";
  }
};

const getBgStyle = (type: BackgroundType, niche: Niche): React.CSSProperties => {
  // Simulating backgrounds with gradients for the preview
  switch (type) {
    case BackgroundType.Outdoor: return { background: 'linear-gradient(to bottom right, #38bdf8, #166534)' };
    case BackgroundType.Studio: return { background: 'linear-gradient(to bottom, #374151, #111827)' };
    case BackgroundType.Abstract: return { background: 'linear-gradient(45deg, #6366f1, #ec4899, #eab308)' };
    case BackgroundType.Urban: return { background: 'linear-gradient(to top, #1e293b, #475569)' };
    default: return { backgroundColor: '#262626' };
  }
};

const getLightingOverlay = (lighting: Lighting): string => {
  switch (lighting) {
    case Lighting.Dramatic: return "linear-gradient(45deg, black 0%, transparent 40%, transparent 60%, black 100%)";
    case Lighting.Neon: return "linear-gradient(to right, rgba(0,255,255,0.2), transparent, rgba(255,0,255,0.2))";
    case Lighting.HighContrast: return "radial-gradient(circle, transparent 30%, rgba(0,0,0,0.8) 100%)";
    default: return "none";
  }
};

export const ThumbnailPreview: React.FC<Props> = ({ data }) => {
  const primaryColor = getColorHex(data.colorTheme);
  const bgStyle = getBgStyle(data.backgroundType, data.niche);
  
  // Determine if we show the person silhouette based on FaceType
  const showPerson = [
    FaceType.CloseUp, 
    FaceType.WaistUp, 
    FaceType.Pointing, 
    FaceType.Holding
  ].includes(data.faceType);

  const isPointing = data.faceType === FaceType.Pointing;
  
  // Position adjustment based on Composition
  let subjectPositionClass = "";
  switch(data.composition) {
      case Composition.Centered:
      case Composition.Symmetrical:
          subjectPositionClass = "left-1/2 -translate-x-1/2";
          break;
      case Composition.RuleOfThirds:
          subjectPositionClass = data.textPosition === 'Left' ? "right-[15%]" : "left-[15%]";
          break;
      case Composition.SplitScreen:
           // If split screen, maybe nudge it a bit, but default logic is usually okay
           subjectPositionClass = data.textPosition === 'Left' ? "right-0 md:right-10" : "left-0 md:left-10";
           break;
      default:
           subjectPositionClass = data.textPosition === 'Left' ? "right-0 md:right-10" : "left-0 md:left-10";
  }

  // Override text position for Right logic if user selected Text Position Right but Composition Rule of Thirds suggests left
  // For simplicity, we keep the user's text position preference as dominant but adjust subject to avoid overlap if needed.
  
  return (
    <div className="w-full space-y-2">
      <div className="flex justify-between items-center text-sm text-gray-400">
        <span className="font-semibold uppercase tracking-wider">Design Preview</span>
        <span>16:9 Aspect Ratio</span>
      </div>
      
      {/* The 16:9 Container */}
      <div 
        className="relative w-full aspect-video rounded-lg overflow-hidden shadow-2xl border border-gray-700 group transition-all duration-500"
        style={bgStyle}
      >
        {/* Lighting Overlay */}
        <div 
          className="absolute inset-0 pointer-events-none z-10" 
          style={{ background: getLightingOverlay(data.lighting) }} 
        />

        {/* Composition Guides (Visual Only) */}
        {data.composition === Composition.RuleOfThirds && (
             <div className="absolute inset-0 pointer-events-none z-0 opacity-20">
                 <div className="w-full h-full border-t border-b border-white/30 absolute top-1/3 h-1/3"></div>
                 <div className="w-full h-full border-l border-r border-white/30 absolute left-1/3 w-1/3"></div>
             </div>
        )}
        {data.composition === Composition.SplitScreen && (
             <div className="absolute inset-0 pointer-events-none z-0">
                 <div className="absolute left-1/2 top-0 bottom-0 w-0.5 bg-white/30 -translate-x-1/2"></div>
                 <div className="absolute top-2 left-1/2 -translate-x-1/2 bg-black/50 text-white text-[8px] px-1 rounded">VS</div>
             </div>
        )}
         {data.composition === Composition.Diagonal && (
             <div className="absolute inset-0 pointer-events-none z-0 opacity-10 bg-gradient-to-br from-transparent via-white/20 to-transparent"></div>
        )}

        {/* Mock Subject / Face */}
        <div className={`absolute bottom-0 h-4/5 w-1/2 flex items-end justify-center z-0 transition-all duration-500 ${subjectPositionClass}`}>
          {showPerson ? (
             <div className="relative w-full h-full flex items-end justify-center">
                {/* Silhouette representing a person */}
                <svg viewBox="0 0 100 100" className={`h-full drop-shadow-2xl text-gray-900 fill-current opacity-90 ${isPointing ? 'scale-110' : ''}`}>
                   <path d="M50 40 C 60 40 65 30 65 20 C 65 10 60 0 50 0 C 40 0 35 10 35 20 C 35 30 40 40 50 40 M 10 100 L 90 100 L 80 50 C 80 50 70 45 50 45 C 30 45 20 50 20 50 Z" />
                   {isPointing && (
                     <rect x="0" y="60" width="100" height="10" className="fill-current" />
                   )}
                </svg>
                {/* Emotion Indicator (Abstract) */}
                <div className="absolute top-10 bg-brand-500 text-white text-xs px-2 py-0.5 rounded-full shadow opacity-80">
                  {data.emotion.split('/')[0]}
                </div>
             </div>
          ) : (
             <div className="flex items-center justify-center w-full h-2/3 bg-white/10 backdrop-blur-sm border-2 border-white/20 rounded-xl">
                <span className="text-white/50 font-bold uppercase tracking-widest text-center px-2">
                  {data.faceType === FaceType.HandsOnly ? 'Hands / POV' : `${data.niche} Object`}
                </span>
             </div>
          )}
        </div>

        {/* Text Layer */}
        <div 
          className={`absolute inset-0 p-6 md:p-10 flex flex-col justify-center z-20 ${
            data.textPosition === 'Left' ? 'items-start text-left' :
            data.textPosition === 'Right' ? 'items-end text-right' :
            'items-center text-center'
          }`}
        >
          {data.mainText && (
            <div className="relative max-w-[80%]">
              <h1 
                className="text-4xl md:text-6xl font-black uppercase leading-none transform -rotate-1 drop-shadow-xl"
                style={{ 
                  color: ['White', 'Neon'].includes(data.colorTheme) ? '#ffffff' : primaryColor,
                  textShadow: '4px 4px 0px rgba(0,0,0,0.9)'
                }}
              >
                {data.mainText}
              </h1>
              {/* Optional contrast backing */}
              {['Soft', 'Natural'].includes(data.lighting) === false && (
                 <div className="absolute -inset-2 bg-black/40 blur-lg -z-10 rounded-full"></div>
              )}
            </div>
          )}
        </div>

        {/* UI Elements Mock (Duration, HD) */}
        <div className="absolute bottom-2 right-2 bg-black/80 text-white text-xs font-bold px-1 rounded z-30">
          12:34
        </div>
      </div>
      
      <p className="text-xs text-gray-500 text-center">
        *Visualizer is a layout approximation. The AI Prompt below generates the photorealistic result.*
      </p>
    </div>
  );
};