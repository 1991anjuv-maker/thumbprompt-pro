import React from 'react';

export const SEOContent: React.FC = () => {
  return (
    <div className="max-w-6xl mx-auto px-6 py-16 text-gray-300 space-y-24">
      
      {/* How It Works Section */}
      <section id="how-it-works" className="space-y-12">
        <div className="text-center space-y-4">
          <h2 className="text-3xl font-bold text-white">How to Generate AI Thumbnail Prompts (Not Images)</h2>
          <p className="text-gray-400">A simple 3-step workflow to help improve your Click-Through Rate potential.</p>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          <div className="bg-dark-800 p-8 rounded-2xl border border-gray-800 relative overflow-hidden group h-full flex flex-col">
            <div className="absolute top-0 right-0 p-4 opacity-10 font-black text-6xl text-brand-500 transition-transform group-hover:scale-110">01</div>
            <h3 className="text-xl font-bold text-white mb-4 relative z-10 min-h-[3.5rem] flex items-start">Define Your Concept</h3>
            <p className="text-sm text-gray-400 leading-relaxed relative z-10 flex-grow">
              Input your video topic and a catchy text overlay. Our algorithm understands the context of niches like Gaming, Finance, or Vlogs to suggest relevant prompt imagery.
            </p>
          </div>

          <div className="bg-dark-800 p-8 rounded-2xl border border-gray-800 relative overflow-hidden group h-full flex flex-col">
            <div className="absolute top-0 right-0 p-4 opacity-10 font-black text-6xl text-brand-500 transition-transform group-hover:scale-110">02</div>
            <h3 className="text-xl font-bold text-white mb-4 relative z-10 min-h-[3.5rem] flex items-start">Customize Psychology</h3>
            <p className="text-sm text-gray-400 leading-relaxed relative z-10 flex-grow">
              Thumbnails are psychological triggers. Select specific facial expressions (Shocked, Happy) and color theories (High Contrast, Neon) to attract viewer attention.
            </p>
          </div>

          <div className="bg-dark-800 p-8 rounded-2xl border border-gray-800 relative overflow-hidden group h-full flex flex-col">
            <div className="absolute top-0 right-0 p-4 opacity-10 font-black text-6xl text-brand-500 transition-transform group-hover:scale-110">03</div>
            <h3 className="text-xl font-bold text-white mb-4 relative z-10 min-h-[3.5rem] flex items-start">Generate AI Thumbnail Prompts</h3>
            <p className="text-sm text-gray-400 leading-relaxed relative z-10 flex-grow">
              Optimized for use with popular AI image generation platforms such as Midjourney and DALL·E 3 to create thumbnail images externally.
            </p>
          </div>
        </div>
      </section>

      {/* Deep Dive Content: The Science of CTR */}
      <section className="grid lg:grid-cols-2 gap-16 items-center border-t border-gray-800 pt-16">
        <div className="space-y-6">
          <h2 className="text-3xl font-bold text-white">The Strategy Behind <span className="text-brand-500">High CTR</span></h2>
          <div className="space-y-4 text-gray-400 leading-relaxed">
            <p>
              Your thumbnail is the most important metadata on YouTube. Data suggests that the best-performing videos often have custom thumbnails. But what makes a thumbnail "clicky"?
            </p>
            <ul className="space-y-2 list-disc list-inside marker:text-brand-500 ml-2">
              <li><strong>Facial Cues:</strong> Viewers naturally tend to focus on faces. Intense emotions (fear, joy, shock) trigger interest in the viewer.</li>
              <li><strong>Contrast & Saturation:</strong> Mobile screens are small. High contrast and vibrant colors (like the "Vibrant" setting in our tool) make your image stand out against the white/dark YouTube background.</li>
              <li><strong>Rule of Thirds:</strong> Placing the subject off-center creates dynamic tension and leaves room for text overlays without cluttering the focal point.</li>
            </ul>
          </div>
        </div>
        <div className="bg-dark-800 p-8 rounded-3xl border border-gray-800 shadow-2xl">
          <h3 className="text-xl font-bold text-white mb-6 border-b border-gray-700 pb-4">Platform Optimization Guide</h3>
          <div className="space-y-6">
            <div>
              <h4 className="text-brand-500 font-bold text-sm uppercase tracking-wide mb-2">Midjourney v6</h4>
              <p className="text-xs text-gray-400">Best for photorealistic and artistic styles. Use our “Primary Prompt.” Text elements may need to be added manually in tools like Photoshop or Canva after image creation on the platform.</p>
            </div>
            <div>
              <h4 className="text-brand-500 font-bold text-sm uppercase tracking-wide mb-2">DALL-E 3 (ChatGPT / Bing)</h4>
              <p className="text-xs text-gray-400">Excellent at following detailed instructions and handling text accurately. Use our “Alt 2” prompt, which is descriptive and conversational, for best results on supported platforms.</p>
            </div>
            <div>
              <h4 className="text-brand-500 font-bold text-sm uppercase tracking-wide mb-2">Stable Diffusion XL</h4>
              <p className="text-xs text-gray-400">Ideal for advanced control. Use our “Alt 1” keywords with ControlNet to maintain consistent character faces across multiple thumbnail designs.</p>
            </div>
          </div>
        </div>
      </section>

      {/* Expanded FAQ Section with Schema Markup Context */}
      <section id="faq" className="max-w-4xl mx-auto space-y-8 pt-12">
        <div className="text-center space-y-4">
           <h2 className="text-3xl font-bold text-white">Frequently Asked Questions</h2>
           <p className="text-gray-500">Everything you need to know about AI thumbnail prompts.</p>
        </div>

        <div className="grid gap-4">
          <FAQItem 
            question="Is ThumbPrompt Pro really free?"
            answer="Yes, it is completely free. 'Pro' refers to the advanced prompt logic we use, not a paid service. You can generate unlimited prompts 24/7."
          />
          <FAQItem 
            question="Why don't you generate the images directly?"
            answer="Generating AI images directly requires significant infrastructure and third-party services. Instead, we focus on creating optimized prompts that users can apply within their preferred AI image tools. By generating the 'prompt' instead, we give you the flexibility to use your existing subscriptions (Midjourney, ChatGPT Plus) or free tools (Bing Image Creator) to get the best possible quality without a markup."
          />
          <FAQItem 
            question="How do I add text to AI images?"
            answer="While DALL-E 3 can render text, most professional YouTubers generate a clean background image using AI and then add their text overlay using tools like Photoshop, Canva, or Photopea. This gives you maximum control over font, shadow, and placement."
          />
          <FAQItem 
            question="Does this work for all niches?"
            answer="Absolutely. Our algorithm covers major niches like Gaming (Minecraft, Roblox, COD), Tech Reviews, Finance/Crypto, Vlogging, Cooking, and more. You can select 'General' for any other topic."
          />
          <FAQItem 
            question="Are AI thumbnails copyright free?"
            answer="Generally, yes. Image usage rights depend on the terms and policies of the AI platform you use (such as Midjourney or DALL·E). Users are responsible for reviewing and complying with those terms. ThumbPrompt Pro does not claim ownership over any prompts or images created using external tools."
          />
        </div>
      </section>

      {/* Disclaimer & Footer Info */}
      <section id="disclaimer" className="grid md:grid-cols-2 gap-8 text-xs text-gray-500 border-t border-gray-800 pt-12">
        <div className="space-y-4">
          <h4 className="text-white font-bold uppercase tracking-wider">Disclaimer</h4>
          <p>
            ThumbPrompt Pro is an AI prompt engineering tool. We are not affiliated with YouTube, Google, OpenAI, Midjourney, or any other third-party platforms. The prompts provided are for informational and creative assistance purposes only. Results may vary depending on content quality, implementation, and external factors. No outcomes or performance results are guaranteed.
          </p>
        </div>
        <div className="space-y-4">
           <h4 className="text-white font-bold uppercase tracking-wider">Privacy & Data</h4>
           <p>
             We respect your privacy. This application operates primarily using client-side logic. We do not store personal data, prompt history, or payment information. Limited, non-personal usage data may be collected to improve site functionality and performance.
           </p>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="bg-gradient-to-br from-dark-800 to-dark-900 rounded-3xl p-12 text-center border border-gray-800 shadow-lg">
        <h2 className="text-2xl font-bold text-white mb-4">Need Help?</h2>
        <p className="text-gray-400 mb-8 max-w-lg mx-auto">
          Start generating professional AI thumbnail prompts today. For feature requests, feedback, or general inquiries, feel free to contact us.
        </p>
        <a href="mailto:support@thumbprompt.pro" className="inline-flex items-center gap-2 px-8 py-3 bg-white text-black font-bold rounded-full hover:bg-gray-200 transition-colors">
          <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" /></svg>
          Contact Support
        </a>
      </section>

    </div>
  );
};

const FAQItem: React.FC<{question: string, answer: string}> = ({question, answer}) => {
  return (
    <details className="group bg-dark-900 rounded-lg border border-gray-800 overflow-hidden">
      <summary className="flex cursor-pointer items-center justify-between p-5 font-medium text-white hover:bg-dark-800 transition select-none">
        <span className="text-base md:text-lg">{question}</span>
        <span className="transition-transform duration-300 group-open:rotate-180 text-brand-500">
          <svg fill="none" height="24" width="24" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" viewBox="0 0 24 24"><path d="M6 9l6 6 6-6"></path></svg>
        </span>
      </summary>
      <div className="px-5 pb-5 pt-0">
        <p className="text-sm md:text-base text-gray-400 leading-relaxed border-t border-gray-800 pt-4">
          {answer}
        </p>
      </div>
    </details>
  );
};