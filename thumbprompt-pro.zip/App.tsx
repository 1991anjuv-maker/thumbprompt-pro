import React, { useState, useRef, useEffect } from 'react';
import { Niche, Emotion, Style, ColorTheme, BackgroundType, Lighting, FaceType, Composition, ThumbnailData, GeneratedPrompts } from './types';
import { generatePrompts } from './services/promptGenerator';
import { ThumbnailPreview } from './components/ThumbnailPreview';
import { SEOContent } from './components/SEOContent';
import { AboutUs, PrivacyPolicy, TermsOfService, Disclaimer } from './components/LegalPages';
import { ContactPage } from './components/ContactPage';

const INITIAL_DATA: ThumbnailData = {
  topic: '',
  mainText: '',
  niche: Niche.General,
  emotion: Emotion.Excited,
  faceType: FaceType.CloseUp,
  composition: Composition.RuleOfThirds,
  style: Style.Realistic,
  colorTheme: ColorTheme.Vibrant,
  backgroundType: BackgroundType.Blurred,
  lighting: Lighting.HighContrast,
  textPosition: 'Left'
};

function App() {
  const [view, setView] = useState('home');
  const [data, setData] = useState<ThumbnailData>(INITIAL_DATA);
  const [prompts, setPrompts] = useState<GeneratedPrompts | null>(null);
  const [copied, setCopied] = useState<string | null>(null);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [isGenerating, setIsGenerating] = useState(false);

  const resultsRef = useRef<HTMLDivElement>(null);

  // Robust Navigation Handler
  // This prevents the "refused to connect" error by intercepting clicks 
  // and handling navigation entirely within React state.
  const navigateTo = (e: React.MouseEvent<HTMLAnchorElement> | null, page: string, sectionId?: string) => {
    if (e) e.preventDefault();
    setMobileMenuOpen(false);
    
    // If navigating to a section on the home page (like #how-it-works)
    if (page === 'home' && sectionId) {
      if (view !== 'home') {
        setView('home');
        // Small delay to allow the home component to mount before scrolling
        setTimeout(() => {
          const el = document.getElementById(sectionId);
          if (el) el.scrollIntoView({ behavior: 'smooth' });
        }, 100);
      } else {
        // Already on home, just scroll
        const el = document.getElementById(sectionId);
        if (el) el.scrollIntoView({ behavior: 'smooth' });
      }
    } else {
      // Standard page navigation
      setView(page);
      window.scrollTo(0, 0);
    }
  };

  const handleChange = (field: keyof ThumbnailData, value: any) => {
    setData(prev => ({ ...prev, [field]: value }));
  };

  const handleGenerate = () => {
    if (!data.topic) return;
    
    setIsGenerating(true);
    
    // Simulate API delay for better UX and to allow React to render loading state
    setTimeout(() => {
      const generated = generatePrompts(data);
      setPrompts(generated);
      setIsGenerating(false);
      
      // Smooth scroll to results on mobile with offset for sticky header
      setTimeout(() => {
        if (window.innerWidth < 1024) { 
          resultsRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }
      }, 100);
    }, 600);
  };

  const copyToClipboard = (text: string, key: string) => {
    navigator.clipboard.writeText(text);
    setCopied(key);
    setTimeout(() => setCopied(null), 2000);
  };

  const renderContent = () => {
    switch(view) {
      case 'about': return <AboutUs />;
      case 'privacy': return <PrivacyPolicy />;
      case 'terms': return <TermsOfService />;
      case 'disclaimer': return <Disclaimer />;
      case 'contact': return <ContactPage />;
      case 'home':
      default:
        return (
          <main id="tool" className="max-w-7xl mx-auto px-4 py-8 md:py-12 relative z-0">
            {/* Hero Section */}
            <div className="text-center mb-16 space-y-6 animate-fadeIn max-w-5xl mx-auto relative z-10">
              <h1 className="text-4xl md:text-5xl lg:text-6xl font-black text-white tracking-tight leading-tight drop-shadow-sm">
                AI <span className="text-brand-500">Thumbnail Prompt Generator</span>
                <span className="block mt-2 md:mt-3">for YouTube Creators</span>
              </h1>
              <p className="text-lg text-gray-400 max-w-3xl mx-auto leading-relaxed font-medium">
                Overcome creative block instantly. ThumbPrompt Pro helps YouTube creators generate high-CTR, professional thumbnail prompts using advanced logic and visual psychology. This tool does not generate images directly. It creates optimized AI prompts designed to work with popular AI image generation platforms such as Midjourney v6, DALL·E 3, Stable Diffusion, and Adobe Firefly.
              </p>
            </div>

            <div className="grid lg:grid-cols-12 gap-12 relative z-10">
              {/* LEFT COLUMN: Controls */}
              <div className="lg:col-span-5 space-y-8">
                <div className="space-y-4">
                  <h2 className="text-2xl font-bold flex items-center gap-2">
                    <span className="text-brand-500">1.</span> Video Concept
                  </h2>
                  <div className="space-y-4 bg-dark-800 p-6 rounded-xl border border-gray-800 shadow-sm">
                    <div>
                      <label className="block text-sm font-medium text-gray-400 mb-1">Video Topic</label>
                      <input 
                        type="text" 
                        placeholder="e.g. I Survived 100 Days in Minecraft"
                        className="w-full bg-dark-900 border border-gray-700 rounded-lg p-3 text-white focus:ring-2 focus:ring-brand-500 focus:border-transparent outline-none transition-all placeholder-gray-600"
                        value={data.topic}
                        onChange={(e) => handleChange('topic', e.target.value)}
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-400 mb-1">Thumbnail Text (Max 4 words)</label>
                      <input 
                        type="text" 
                        placeholder="e.g. IMPOSSIBLE?"
                        className="w-full bg-dark-900 border border-gray-700 rounded-lg p-3 text-white focus:ring-2 focus:ring-brand-500 focus:border-transparent outline-none transition-all placeholder-gray-600 font-bold uppercase tracking-wider"
                        value={data.mainText}
                        onChange={(e) => handleChange('mainText', e.target.value)}
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-400 mb-1">Channel Niche</label>
                      <select 
                        className="w-full bg-dark-900 border border-gray-700 rounded-lg p-3 text-white focus:ring-2 focus:ring-brand-500 outline-none"
                        value={data.niche}
                        onChange={(e) => handleChange('niche', e.target.value)}
                      >
                        {Object.values(Niche).map((v) => <option key={v} value={v}>{v}</option>)}
                      </select>
                    </div>
                  </div>
                </div>

                <div className="space-y-4">
                  <h2 className="text-2xl font-bold flex items-center gap-2">
                    <span className="text-brand-500">2.</span> Psychology & Style
                  </h2>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 bg-dark-800 p-6 rounded-xl border border-gray-800 shadow-sm">
                    <div>
                      <label className="block text-xs font-bold text-gray-500 uppercase mb-1">Emotion</label>
                      <select 
                        className="w-full bg-dark-900 border border-gray-700 rounded-lg p-2.5 text-sm text-white focus:ring-1 focus:ring-brand-500 outline-none"
                        value={data.emotion}
                        onChange={(e) => handleChange('emotion', e.target.value)}
                      >
                        {Object.values(Emotion).map((v) => <option key={v} value={v}>{v}</option>)}
                      </select>
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-gray-500 uppercase mb-1">Visual Style</label>
                      <select 
                        className="w-full bg-dark-900 border border-gray-700 rounded-lg p-2.5 text-sm text-white focus:ring-1 focus:ring-brand-500 outline-none"
                        value={data.style}
                        onChange={(e) => handleChange('style', e.target.value)}
                      >
                        {Object.values(Style).map((v) => <option key={v} value={v}>{v}</option>)}
                      </select>
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-gray-500 uppercase mb-1">Color Theme</label>
                      <select 
                        className="w-full bg-dark-900 border border-gray-700 rounded-lg p-2.5 text-sm text-white focus:ring-1 focus:ring-brand-500 outline-none"
                        value={data.colorTheme}
                        onChange={(e) => handleChange('colorTheme', e.target.value)}
                      >
                        {Object.values(ColorTheme).map((v) => <option key={v} value={v}>{v}</option>)}
                      </select>
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-gray-500 uppercase mb-1">Background</label>
                      <select 
                        className="w-full bg-dark-900 border border-gray-700 rounded-lg p-2.5 text-sm text-white focus:ring-1 focus:ring-brand-500 outline-none"
                        value={data.backgroundType}
                        onChange={(e) => handleChange('backgroundType', e.target.value)}
                      >
                        {Object.values(BackgroundType).map((v) => <option key={v} value={v}>{v}</option>)}
                      </select>
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-gray-500 uppercase mb-1">Lighting</label>
                      <select 
                        className="w-full bg-dark-900 border border-gray-700 rounded-lg p-2.5 text-sm text-white focus:ring-1 focus:ring-brand-500 outline-none"
                        value={data.lighting}
                        onChange={(e) => handleChange('lighting', e.target.value)}
                      >
                        {Object.values(Lighting).map((v) => <option key={v} value={v}>{v}</option>)}
                      </select>
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-gray-500 uppercase mb-1">Face Type</label>
                      <select 
                        className="w-full bg-dark-900 border border-gray-700 rounded-lg p-2.5 text-sm text-white focus:ring-1 focus:ring-brand-500 outline-none"
                        value={data.faceType}
                        onChange={(e) => handleChange('faceType', e.target.value)}
                      >
                        {Object.values(FaceType).map((v) => <option key={v} value={v}>{v}</option>)}
                      </select>
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-gray-500 uppercase mb-1">Composition</label>
                      <select 
                        className="w-full bg-dark-900 border border-gray-700 rounded-lg p-2.5 text-sm text-white focus:ring-1 focus:ring-brand-500 outline-none"
                        value={data.composition}
                        onChange={(e) => handleChange('composition', e.target.value)}
                      >
                        {Object.values(Composition).map((v) => <option key={v} value={v}>{v}</option>)}
                      </select>
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-gray-500 uppercase mb-1">Text Position</label>
                      <div className="flex gap-2">
                        <button 
                          onClick={() => handleChange('textPosition', data.textPosition === 'Left' ? 'Right' : data.textPosition === 'Right' ? 'Center' : 'Left')}
                          className="w-full py-2.5 rounded border border-gray-700 bg-dark-900 text-gray-400 text-xs font-medium hover:border-gray-500 transition-colors"
                        >
                          {data.textPosition}
                        </button>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Mobile Sticky Button */}
                <div className="sticky bottom-4 z-40 lg:static">
                  <button 
                    onClick={handleGenerate}
                    disabled={!data.topic || isGenerating}
                    className="w-full py-4 bg-gradient-to-r from-brand-600 to-rose-600 hover:from-brand-500 hover:to-rose-500 text-white font-bold text-lg rounded-xl shadow-lg shadow-brand-900/50 disabled:opacity-50 disabled:cursor-not-allowed transform active:scale-[0.98] transition-all flex items-center justify-center gap-2"
                  >
                    {isGenerating ? (
                      <>
                        <svg className="animate-spin -ml-1 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                          <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                          <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                        </svg>
                        Generating...
                      </>
                    ) : (
                      <>
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M21 12a9 9 0 1 1-6.219-8.56"></path></svg>
                        {prompts ? 'Regenerate Prompts' : 'Generate Prompts'}
                      </>
                    )}
                  </button>
                  {!data.topic && (
                    <p className="text-center text-xs text-rose-400 mt-2">Enter a topic to start</p>
                  )}
                </div>
              </div>

              {/* RIGHT COLUMN: Output */}
              <div className="lg:col-span-7 space-y-8 scroll-mt-32" ref={resultsRef}>
                <h2 className="text-2xl font-bold flex items-center gap-2 lg:hidden">
                  <span className="text-brand-500">3.</span> Results
                </h2>

                {/* Visual Preview */}
                <div className="bg-dark-800 p-2 rounded-xl border border-gray-700">
                  <ThumbnailPreview data={data} />
                </div>

                {/* Prompt Outputs */}
                {prompts ? (
                  <div className="space-y-6 animate-fadeIn">
                    <div className="bg-dark-800 rounded-xl border border-gray-700 overflow-hidden">
                      <div className="bg-gradient-to-r from-gray-800 to-gray-900 px-6 py-3 border-b border-gray-700 flex justify-between items-center">
                        <h3 className="font-bold text-brand-400 flex items-center gap-2">
                          <span className="w-2 h-2 rounded-full bg-brand-500 animate-pulse"></span>
                          Primary Prompt (Best for Midjourney)
                        </h3>
                        <button 
                          onClick={() => copyToClipboard(prompts.main, 'main')}
                          className="text-xs bg-dark-700 hover:bg-dark-600 px-3 py-1 rounded-full transition-colors text-white border border-gray-600"
                        >
                          {copied === 'main' ? 'Copied!' : 'Copy'}
                        </button>
                      </div>
                      <div className="p-6">
                        <p className="text-gray-300 leading-relaxed font-mono text-sm">{prompts.main}</p>
                      </div>
                    </div>

                    <div className="grid md:grid-cols-2 gap-4">
                      <div className="bg-dark-800 rounded-xl border border-gray-700 overflow-hidden">
                        <div className="bg-gray-800/50 px-4 py-2 border-b border-gray-700 flex justify-between items-center">
                          <h3 className="font-semibold text-sm text-gray-300">Style Variation (Artistic)</h3>
                          <button 
                            onClick={() => copyToClipboard(prompts.alt1, 'alt1')}
                            className="text-xs text-brand-400 hover:text-brand-300"
                          >
                            {copied === 'alt1' ? 'Copied!' : 'Copy'}
                          </button>
                        </div>
                        <div className="p-4">
                          <p className="text-gray-400 text-xs leading-relaxed font-mono">{prompts.alt1}</p>
                        </div>
                      </div>

                      <div className="bg-dark-800 rounded-xl border border-gray-700 overflow-hidden">
                        <div className="bg-gray-800/50 px-4 py-2 border-b border-gray-700 flex justify-between items-center">
                          <h3 className="font-semibold text-sm text-gray-300">DALL-E 3 / Bing Optimized</h3>
                          <button 
                            onClick={() => copyToClipboard(prompts.alt2, 'alt2')}
                            className="text-xs text-brand-400 hover:text-brand-300"
                          >
                            {copied === 'alt2' ? 'Copied!' : 'Copy'}
                          </button>
                        </div>
                        <div className="p-4">
                          <p className="text-gray-400 text-xs leading-relaxed font-mono">{prompts.alt2}</p>
                        </div>
                      </div>
                    </div>

                    <div className="bg-brand-900/20 border border-brand-900/50 p-4 rounded-lg text-sm text-brand-200 flex items-start gap-3">
                      <div className="mt-1">
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><circle cx="12" cy="12" r="10"></circle><line x1="12" y1="8" x2="12" y2="12"></line><line x1="12" y1="16" x2="12.01" y2="16"></line></svg>
                      </div>
                      <p>
                        <strong>Tip:</strong> Paste these prompts into Bing Image Creator, Midjourney, or Leonardo.ai. These are prompt-generation results only; you will need an external AI image tool to render the final image.
                      </p>
                    </div>
                  </div>
                ) : (
                  <div className="w-full min-h-[300px] flex flex-col items-center justify-center border-2 border-dashed border-gray-700/50 rounded-xl bg-dark-900/30 text-gray-400">
                    <svg className="w-16 h-16 mb-4 opacity-50" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"></path></svg>
                    <p className="font-medium text-center px-4">Fill out the form and click Generate</p>
                  </div>
                )}
              </div>
            </div>

            {/* SEO / Content Section */}
            <div className="mt-24 border-t border-gray-800">
              <SEOContent />
            </div>
          </main>
        );
    }
  };

  return (
    <div className="min-h-screen bg-[#121212] text-gray-100 font-sans selection:bg-brand-500 selection:text-white flex flex-col">
      {/* Header */}
      <header className="border-b border-gray-800 bg-[#121212]/90 backdrop-blur sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
          <a href="#" onClick={(e) => navigateTo(e, 'home')} className="flex items-center gap-2 hover:opacity-90 transition-opacity">
            <div className="w-8 h-8 bg-gradient-to-br from-brand-500 to-orange-500 rounded-lg flex items-center justify-center font-bold text-white shadow-lg shadow-brand-500/20">
              T
            </div>
            <h1 className="text-xl font-bold tracking-tight">Thumb<span className="text-brand-500">Prompt</span> Pro</h1>
          </a>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center gap-8">
            <a href="#" onClick={(e) => navigateTo(e, 'home')} className={`text-sm font-medium transition-colors ${view === 'home' ? 'text-brand-500' : 'text-gray-400 hover:text-white'}`}>Home</a>
            <a href="#" onClick={(e) => navigateTo(e, 'about')} className={`text-sm font-medium transition-colors ${view === 'about' ? 'text-brand-500' : 'text-gray-400 hover:text-white'}`}>About Us</a>
            <a href="#" onClick={(e) => navigateTo(e, 'contact')} className={`text-sm font-medium transition-colors ${view === 'contact' ? 'text-brand-500' : 'text-gray-400 hover:text-white'}`}>Contact</a>
          </nav>

          {/* Mobile Menu Icon */}
          <button 
            className="md:hidden text-gray-400 hover:text-white p-2"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          >
            {mobileMenuOpen ? (
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>
            ) : (
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="3" y1="12" x2="21" y2="12"></line><line x1="3" y1="6" x2="21" y2="6"></line><line x1="3" y1="18" x2="21" y2="18"></line></svg>
            )}
          </button>
        </div>
      </header>

      {/* Mobile Menu Overlay */}
      {mobileMenuOpen && (
        <div className="md:hidden fixed inset-0 z-40 bg-black/95 pt-24 px-6 animate-fadeIn overflow-y-auto">
          <nav className="flex flex-col gap-6 text-xl font-medium text-gray-300">
             <a href="#" onClick={(e) => navigateTo(e, 'home')} className="border-b border-gray-800 pb-2">Home</a>
             <a href="#" onClick={(e) => navigateTo(e, 'home', 'tool')} className="border-b border-gray-800 pb-2">Generator Tool</a>
             <a href="#" onClick={(e) => navigateTo(e, 'about')} className="border-b border-gray-800 pb-2">About Us</a>
             <a href="#" onClick={(e) => navigateTo(e, 'contact')} className="border-b border-gray-800 pb-2">Contact</a>
             <a href="#" onClick={(e) => navigateTo(e, 'privacy')} className="border-b border-gray-800 pb-2">Privacy Policy</a>
             <a href="#" onClick={(e) => navigateTo(e, 'terms')} className="border-b border-gray-800 pb-2">Terms of Service</a>
             <a href="#" onClick={(e) => navigateTo(e, 'disclaimer')} className="border-b border-gray-800 pb-2">Disclaimer</a>
          </nav>
        </div>
      )}

      <div className="flex-grow">
        {renderContent()}
      </div>

      <footer className="bg-black border-t border-gray-900 mt-auto">
        <div className="max-w-7xl mx-auto px-4 py-12">
          {/* Top Footer Section */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-12">
            
            {/* Branding Column */}
            <div className="md:col-span-1 space-y-4">
              <div className="flex items-center gap-2">
                <div className="w-6 h-6 bg-brand-500 rounded flex items-center justify-center font-bold text-white text-xs">T</div>
                <span className="text-xl font-bold text-white">Thumb<span className="text-brand-500">Prompt</span> Pro</span>
              </div>
              <p className="text-gray-400 text-sm leading-relaxed">
                A free AI prompt generator designed for YouTube content creators. "Pro" refers to our advanced prompt engineering logic, not a paid tier. This tool is 100% free.
              </p>
            </div>

            {/* Quick Links Column */}
            <div>
              <h3 className="text-white font-bold text-sm uppercase tracking-wider mb-6">Quick Links</h3>
              <ul className="space-y-3 text-sm text-gray-400">
                <li><a href="#" onClick={(e) => navigateTo(e, 'home')} className="hover:text-brand-500 transition-colors">Home</a></li>
                <li><a href="#" onClick={(e) => navigateTo(e, 'about')} className="hover:text-brand-500 transition-colors">About Us</a></li>
                <li><a href="#" onClick={(e) => navigateTo(e, 'home', 'how-it-works')} className="hover:text-brand-500 transition-colors">How It Works</a></li>
              </ul>
            </div>

            {/* Legal Column */}
            <div>
              <h3 className="text-white font-bold text-sm uppercase tracking-wider mb-6">Legal</h3>
              <ul className="space-y-3 text-sm text-gray-400">
                <li><a href="#" onClick={(e) => navigateTo(e, 'privacy')} className="hover:text-brand-500 transition-colors">Privacy Policy</a></li>
                <li><a href="#" onClick={(e) => navigateTo(e, 'terms')} className="hover:text-brand-500 transition-colors">Terms of Service</a></li>
                <li><a href="#" onClick={(e) => navigateTo(e, 'disclaimer')} className="hover:text-brand-500 transition-colors">Disclaimer</a></li>
              </ul>
            </div>

            {/* Contact Column */}
            <div>
              <h3 className="text-white font-bold text-sm uppercase tracking-wider mb-6">Contact</h3>
              <ul className="space-y-3 text-sm text-gray-400">
                <li className="text-xs leading-relaxed text-gray-500">Questions or suggestions?</li>
                <li><a href="#" onClick={(e) => navigateTo(e, 'contact')} className="hover:text-brand-500 transition-colors text-brand-500">Contact Support</a></li>
              </ul>
            </div>
          </div>

          {/* Bottom Footer Bar */}
          <div className="border-t border-gray-800 pt-8 flex flex-col gap-4 text-center">
            <div className="flex flex-col md:flex-row justify-between items-center gap-4">
                <p className="text-gray-600 text-xs">
                &copy; {new Date().getFullYear()} ThumbPrompt Pro. All rights reserved.
                </p>
                <p className="text-gray-700 text-[10px] max-w-md md:text-right">
                This site is not affiliated with YouTube, Google, OpenAI, Midjourney, DALL·E, Stable Diffusion, or Adobe. All brand names are used only for reference and compatibility purposes.
                </p>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;