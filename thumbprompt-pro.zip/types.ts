export enum Niche {
  General = "General",
  Gaming = "Gaming",
  Tech = "Tech & Gadgets",
  Finance = "Finance & Crypto",
  Vlog = "Lifestyle & Vlog",
  Educational = "Educational",
  News = "News & Politics",
  Fitness = "Health & Fitness",
  Cooking = "Cooking & Food",
  Horror = "Horror & Mystery"
}

export enum Emotion {
  Excited = "Excited/Shocked",
  Angry = "Angry/Critical",
  Sad = "Sad/Disappointed",
  Happy = "Happy/Joyful",
  Scared = "Scared/Terrified",
  Curious = "Curious/Secretive",
  Serious = "Serious/Professional",
  Neutral = "Neutral"
}

export enum FaceType {
  CloseUp = "Close-up Face",
  WaistUp = "Waist-up Shot",
  Pointing = "Person Pointing at Text",
  Holding = "Person Holding Object",
  NoFaceObject = "No Face - Main Object Focus",
  NoFaceText = "No Face - Text Only Focus",
  HandsOnly = "Hands Only (e.g. Unboxing)"
}

export enum Composition {
  RuleOfThirds = "Rule of Thirds",
  Centered = "Centered Subject",
  SplitScreen = "Split Screen (Comparison)",
  Diagonal = "Diagonal Dynamic",
  Symmetrical = "Symmetrical Balance",
  WideAngle = "Wide Angle / Panorama"
}

export enum Style {
  Realistic = "Hyper-Realistic Photo",
  Cinematic = "Cinematic Movie Scene",
  Cartoon = "Cartoon/Vector Art",
  Anime = "Anime Style",
  ThreeDRender = "3D Render (Blender/Unreal)",
  Painting = "Digital Painting",
  Minimalist = "Minimalist",
  Cyberpunk = "Cyberpunk/Neon"
}

export enum ColorTheme {
  Vibrant = "Vibrant (High Saturation)",
  Dark = "Dark & Moody",
  Neon = "Neon Lights",
  Pastel = "Pastel & Soft",
  Red = "Red (Danger/Alert)",
  Green = "Green (Money/Success)",
  Blue = "Blue (Trust/Tech)",
  Gold = "Gold & Luxury"
}

export enum BackgroundType {
  Blurred = "Blurred Depth of Field",
  Studio = "Solid Studio Color",
  Outdoor = "Outdoor Nature",
  Urban = "Urban City Street",
  Abstract = "Abstract Gradient",
  Interior = "Room Interior",
  Gameplay = "Gameplay Screenshot"
}

export enum Lighting {
  HighContrast = "High Contrast (Rembrandt)",
  Soft = "Soft Studio Lighting",
  Dramatic = "Dramatic Backlight (Rim Light)",
  Natural = "Natural Daylight",
  Neon = "Neon Glow"
}

export interface ThumbnailData {
  topic: string;
  mainText: string;
  niche: Niche;
  emotion: Emotion;
  faceType: FaceType;
  composition: Composition;
  style: Style;
  colorTheme: ColorTheme;
  backgroundType: BackgroundType;
  lighting: Lighting;
  textPosition: 'Left' | 'Center' | 'Right';
}

export interface GeneratedPrompts {
  main: string;
  alt1: string;
  alt2: string;
}