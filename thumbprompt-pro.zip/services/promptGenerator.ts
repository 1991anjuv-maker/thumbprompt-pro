import { ThumbnailData, Niche, Emotion, Style, FaceType, Composition, Lighting, GeneratedPrompts } from '../types';

// Helper to pick a random option from an array
const sample = (arr: string[]) => arr[Math.floor(Math.random() * arr.length)];

const getNicheKeywords = (niche: Niche): string => {
  switch (niche) {
    case Niche.Gaming: return sample([
      "gaming setup, controller in hand, rgb lighting, intense gameplay moment, 4k screenshot background",
      "esports stage atmosphere, neon geometric shapes, shouting into microphone, headset close-up, victory royale text",
      "retro arcade vibes, pixel art overlay, glowing joystick, action-packed screen capture"
    ]);
    case Niche.Tech: return sample([
      "latest gadget review, circuit board overlay, futuristic technology, clean desk setup, glowing screen",
      "holographic interface, floating smartphone, tech reviewer studio, blue lighting accents, 8k product shot",
      "macro shot of processor, server room background, smart home devices, minimalist white desk setup"
    ]);
    case Niche.Finance: return sample([
      "flying money, stock charts going up, green arrows, gold coins pile, luxury suit, bitcoin symbol",
      "shocked investor, burning money concept, wall street background, financial crisis graph, wallet explosion",
      "crypto mining rig, digital currency hologram, stack of cash, analyzing market data, bull market"
    ]);
    case Niche.Educational: return sample([
      "blackboard background, floating math formulas, science equipment, bookshelf, bright studio lighting",
      "library setting, stack of books, thinking pose, eureka moment, pencil sketch overlay, infographics",
      "laboratory background, microscope, chemical reaction, history map, graduation cap, knowledge glow"
    ]);
    case Niche.Fitness: return sample([
      "gym environment, sweating, flexing muscles, workout gear, protein shake, high energy motion blur",
      "outdoor running track, sunrise yoga, healthy food spread, measuring tape, transformation comparison",
      "crossfit box, lifting heavy weights, intense determination, anatomy muscle chart overlay, water bottle"
    ]);
    case Niche.Horror: return sample([
      "dark shadows, misty fog, haunted house background, glitch effect, scary silhouette in window",
      "creepy doll, red eyes glowing in dark, abandoned asylum, blood splatter text, flashlight beam",
      "ghostly figure, graveyard at night, jump scare face, distorted reality, fear expression"
    ]);
    case Niche.Cooking: return sample([
      "delicious food close-up, steam rising, chef uniform, kitchen background, fresh ingredients explosion",
      "tasting spoon, mouth watering, chopping vegetables, flames from pan, rustic wooden table",
      "gourmet plating, bokeh restaurant background, messy kitchen fun, baking flour dust, vibrant spices"
    ]);
    default: return sample(["engaging background", "youtube trending aesthetic", "high click-through rate composition"]);
  }
};

const getEmotionDetails = (emotion: Emotion): string => {
  switch (emotion) {
    case Emotion.Excited: return sample([
      "mouth open in shock, eyes wide, hands on cheeks, extreme excitement, wow face",
      "pointing at camera with excitement, jaw dropped, celebrating victory, energetic scream",
      "grabbing head in disbelief, massive smile, exploding with joy, dynamic motion"
    ]);
    case Emotion.Angry: return sample([
      "furrowed brows, shouting, red face, intense angry stare, pointing finger aggressively",
      "steaming with rage, clenched fists, gritting teeth, explosion background, conflict",
      "frustrated expression, tearing hair out, crossing arms defensively, critical look"
    ]);
    case Emotion.Scared: return sample([
      "looking terrified, covering mouth, pale face, eyes wide with fear, sweating, trembling",
      "hiding behind hands, peeking through fingers, screaming in terror, running away pose",
      "frozen in fear, goosebumps, wide-eyed panic, shadow looming over"
    ]);
    case Emotion.Curious: return sample([
      "looking through magnifying glass, thinking pose, hand on chin, raising one eyebrow, mysterious look",
      "scratching head, question marks floating, investigating object, leaning in closely",
      "squinting eyes, analyzing detail, holding blueprint, puzzle pieces, detective vibe"
    ]);
    case Emotion.Sad: return sample([
      "crying, looking down, tears, dark moody atmosphere, head in hands, rain window",
      "disappointed frown, slump posture, heartbreak symbol, monochrome filter, lonely",
      "wiping tear, looking at ground, hopeless expression, rainy background, regret"
    ]);
    case Emotion.Happy: return sample([
      "big bright smile, thumbs up, laughing, positive energy, winning pose, confetti",
      "holding trophy, peace sign, radiant glow, friends laughing, sun flare",
      "clapping hands, fist pump, joyful tears, success gesture, confident grin"
    ]);
    default: return sample(["confident direct eye contact", "professional headshot", "engaging presenter look"]);
  }
};

const getStyleKeywords = (style: Style): string => {
  switch (style) {
    case Style.Realistic: return sample([
      "hyper-realistic, 8k resolution, shot on Sony A7R IV, highly detailed skin texture, depth of field",
      "photorealistic masterpiece, raw photo, sharp focus, studio photography, national geographic quality",
      "4k uhd, detailed pores, realistic lighting, canon 5d mark iv, cinematic color grading"
    ]);
    case Style.ThreeDRender: return sample([
      "3D blender render, unreal engine 5, plastic texture, pixar style, claymation look, octane render",
      "c4d render, isometric view, glossy materials, toy-like aesthetic, volumetric lighting",
      "high fidelity 3d, digital sculpting, zbrush detail, subsurface scattering, disney animation style"
    ]);
    case Style.Anime: return sample([
      "anime art style, vibrant cel shading, manga aesthetic, speed lines, studio ghibli inspired",
      "shonen jump style, dramatic angles, energy aura, detailed eyes, makoto shinkai background",
      "cyberpunk anime, neon outlines, emotional anime face, action sequence, hand drawn animation"
    ]);
    case Style.Cyberpunk: return sample([
      "cyberpunk aesthetic, neon blue and pink lights, futuristic city, glitch art effects, synthwave",
      "blade runner vibe, high tech hud, rainy neon street, chrome reflections, dystopia",
      "night city background, glowing tattoos, futuristic visor, purple haze, retro-futurism"
    ]);
    case Style.Cartoon: return sample([
      "vibrant vector art, thick outlines, bold colors, fortnite art style, comic book shading",
      "spongebob style exaggeration, colorful flat design, expressive caricature, pop art halftone",
      "modern illustration, clean lines, mascot logo style, sticker art, bright palette"
    ]);
    default: return "cinematic composition, movie poster quality, masterpiece";
  }
};

const getLightingKeywords = (lighting: Lighting): string => {
  switch (lighting) {
    case Lighting.Dramatic: return sample([
      "dramatic rim lighting, backlight, volumetric fog, god rays, silhouette",
      "chiaroscuro, deep shadows, cinematic noir, spotlight, mood lighting"
    ]);
    case Lighting.HighContrast: return sample([
      "high contrast shadows, rembrandt lighting, sharp focus, hard light",
      "vibrant contrast, punchy colors, clarity boost, dynamic range"
    ]);
    case Lighting.Neon: return sample([
      "glowing neon lights, dual tone lighting (blue and orange), futuristic glow",
      "cyberpunk lighting, ultraviolet, led strip background, night club vibes"
    ]);
    default: return "soft studio box lighting, professional photography lighting, evenly lit, ring light reflection";
  }
};

const getCompositionKeywords = (composition: Composition): string => {
  switch (composition) {
    case Composition.RuleOfThirds: return "composition following rule of thirds, subject placed on power point, balanced negative space";
    case Composition.Centered: return "perfectly centered composition, symmetrical balance, subject in dead center, wes anderson style framing";
    case Composition.SplitScreen: return "split screen effect, before and after comparison, left side vs right side, versus mode";
    case Composition.Diagonal: return "dynamic diagonal composition, tilted horizon, dutch angle, action-oriented framing";
    case Composition.Symmetrical: return "perfect symmetry, mirror image composition, balanced weight, kaleidoscopic effect";
    case Composition.WideAngle: return "ultra wide angle shot, gopro view, fisheye lens effect, vast scale, barrel distortion";
    default: return "cinematic composition, balanced framing";
  }
};

const getSubjectDescription = (faceType: FaceType, emotionKw: string, topic: string, nicheKw: string): string => {
  switch (faceType) {
    case FaceType.CloseUp:
      return `Extreme close-up shot of a person with a ${emotionKw}, looking directly at camera, capturing fine facial details`;
    case FaceType.WaistUp:
      return `Waist-up medium shot of a YouTuber posing with ${emotionKw}, dynamic gesture, wearing attire suitable for ${nicheKw}`;
    case FaceType.Pointing:
      return `Person looking ${emotionKw} and pointing fingers specifically towards the text area, high energy`;
    case FaceType.Holding:
      return `Person holding a central object relevant to ${topic}, looking ${emotionKw}, focus on the interaction with the item`;
    case FaceType.HandsOnly:
      return `First-person POV, hands holding or unboxing an item related to ${topic}, close-up on hands and object, no face`;
    case FaceType.NoFaceObject:
      return `Focus on a central object related to ${topic}, iconic imagery, highly detailed product shot or concept art, no people`;
    case FaceType.NoFaceText:
      return `Text-heavy composition with abstract background elements related to ${topic}, clean negative space, no people`;
    default:
      return `Person with ${emotionKw}`;
  }
};

export const generatePrompts = (data: ThumbnailData): GeneratedPrompts => {
  const { topic, niche, emotion, faceType, composition, style, colorTheme, backgroundType, lighting, mainText } = data;

  const baseStructure = `YouTube thumbnail for a video about "${topic}".`;
  const styleKw = getStyleKeywords(style);
  const emotionKw = getEmotionDetails(emotion);
  const nicheKw = getNicheKeywords(niche);
  const lightKw = getLightingKeywords(lighting);
  const compKw = getCompositionKeywords(composition);
  
  // Constructing the Subject
  const subject = getSubjectDescription(faceType, emotionKw, topic, nicheKw);

  // Constructing Background
  const bg = `${backgroundType} background, ${colorTheme} color palette.`;

  // Randomize prompt structure slightly for variety
  const structures = [
    `${baseStructure} ${styleKw}. ${compKw}. ${subject}. Background: ${bg} with elements of ${nicheKw}. Lighting: ${lightKw}.`,
    `An engaging ${styleKw} YouTube thumbnail of ${topic}. ${subject}. ${compKw}, ${lightKw}, ${bg}.`,
    `${subject} in the style of ${styleKw}. ${nicheKw} atmosphere. ${compKw} with ${lightKw}.`
  ];

  const mainStructure = sample(structures);

  // Main Prompt (Optimized for Midjourney/DALL-E 3)
  const main = `
    ${mainStructure}
    Text: Include bold, legible text saying "${mainText}" in a sans-serif font placed on the ${data.textPosition}.
    Details: High saturation, 16:9 aspect ratio, trending on ArtStation, ultra-detailed, 8k, sharp focus, high-impact aesthetic.
  `.replace(/\s+/g, ' ').trim();

  // Alt 1: Simplified/Artistic (Better for Stable Diffusion)
  const alt1 = `
    (Best quality, masterpiece), ${style}, ${topic} concept art.
    ${compKw}. ${subject}, ${nicheKw}.
    ${backgroundType}, ${lighting}, ${colorTheme}.
    No text, 16:9, 8k uhd.
  `.replace(/\s+/g, ' ').trim();

  // Alt 2: Descriptive (Better for Bing/DALL-E 3)
  const alt2 = `
    A YouTube thumbnail image showing ${topic}. 
    The composition uses ${compKw}.
    The scene features ${subject}.
    The atmosphere is ${colorTheme} and ${lighting}.
    The background is ${backgroundType}.
    There is large, high-contrast text that reads "${mainText}".
    The image is designed to be very catchy, high contrast, and exciting.
  `.replace(/\s+/g, ' ').trim();

  return { main, alt1, alt2 };
};